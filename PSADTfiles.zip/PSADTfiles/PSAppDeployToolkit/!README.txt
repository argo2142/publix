﻿The content within this folder is digitally signed and modification of any config, string, script, or any other file, is not supported by the PSAppDeployToolkit team.

To create a new deployment, which will include config and script directories you can modify, please refer to https://psappdeploytoolkit.com/docs/getting-started/creating-a-new-deployment.

To review the directory structure to see where the config, string, or asset files are that you can modify to suit your environment, please refer to https://psappdeploytoolkit.com/docs/deployment-concepts/deployment-structure.
